using System;
using System.Collections.Generic;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace CybersecurityChatbot
{
    public delegate void  ResponseGeneratedHandler(string response, SentimentType sentiment);

    public enum SentimentType { Neutral, Worried, Curious, Frustrated, Positive }

    public class UserMemory
    {
        public string Name { get; set; } = "";
        public string FavouriteTopic { get; set; } = "";
        public string LastTopic { get; set; } = "";
        public int QuestionCount { get; set; } = 0;
    }

    public class ChatBot
    {
        public event ResponseGeneratedHandler OnResponseGenerated;
        private readonly Random _rng = new Random();
        private readonly UserMemory _mem = new UserMemory();

        private readonly Dictionary<string, List<string>> _responses = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
        {
            ["password"] = new List<string> {
                "Use strong, unique passwords for every account.",
                "Never reuse passwords across websites.",
                "Use a password manager for better security."
            },
            ["phishing"] = new List<string> {
                "Be careful of suspicious emails asking for personal information.",
                "Always verify links before clicking them.",
                "Phishing scams often create urgency to trick users."
            },
            ["privacy"] = new List<string> {
                "Review your social media privacy settings regularly.",
                "Avoid oversharing personal information online.",
                "Use secure passwords and 2FA to protect accounts."
            }
        };

        public void SetName(string name) => _mem.Name = name;

        public UserMemory GetMemory() => _mem;

        public string Process(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return "Please type something.";

            _mem.QuestionCount++;
            string low = input.ToLower();

            SentimentType sentiment = DetectSentiment(low);
            string response = BuildReply(low, sentiment);

            OnResponseGenerated?.Invoke(response, sentiment);
            return response;
        }

        private SentimentType DetectSentiment(string input)
        {
            if (input.Contains("worried") || input.Contains("scared"))
                return SentimentType.Worried;

            if (input.Contains("curious") || input.Contains("interested"))
                return SentimentType.Curious;

            if (input.Contains("confused"))
                return SentimentType.Frustrated;

            if (input.Contains("thanks"))
                return SentimentType.Positive;

            return SentimentType.Neutral;
        }

        private string BuildReply(string low, SentimentType sentiment)
        {
            string prefix = "";

            switch (sentiment)
            {
                case SentimentType.Worried:
                    prefix = "Don't worry, ";
                    break;

                case SentimentType.Curious:
                    prefix = "Great question! ";
                    break;

                case SentimentType.Frustrated:
                    prefix = "Let me simplify it. ";
                    break;

                case SentimentType.Positive:
                    prefix = "Glad to help! ";
                    break;
            }

            foreach (var item in _responses)
            {
                if (low.Contains(item.Key))
                {
                    _mem.LastTopic = item.Key;
                    return prefix + item.Value[_rng.Next(item.Value.Count)];
                }
            }

            return "Try asking about passwords, phishing, or privacy.";
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    public class MainForm : Form
    {
        private readonly ChatBot _bot = new ChatBot();

        RichTextBox rtbChat;
        TextBox txtInput;
        Button btnSend;

        public MainForm()
        {
            Text = "Cybersecurity Awareness Chatbot";
            Size = new Size(800, 600);
            BackColor = Color.Blue;

            rtbChat = new RichTextBox()
            {
                Dock = DockStyle.Top,
                Height = 450,
                ReadOnly = true,
                BackColor = Color.White,
                ForeColor = Color.Lime,
                Font = new Font("Consolas", 10)
            };

            txtInput = new TextBox()
            {
                Dock = DockStyle.Bottom,
                Height = 30
            };

            btnSend = new Button()
            {
                Text = "Send",
                Dock = DockStyle.Bottom,
                Height = 40
            };

            Controls.Add(rtbChat);
            Controls.Add(btnSend);
            Controls.Add(txtInput);

            btnSend.Click += SendMessage;

            Append("BOT", "Welcome to the Cybersecurity Awareness Chatbot!");
        }

        private void SendMessage(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(input))
                return;

            Append("YOU", input);

            string reply = _bot.Process(input);

            Append("BOT", reply);

            txtInput.Clear();
        }

        private void Append(string who, string message)
        {
            rtbChat.AppendText($"[{DateTime.Now:HH:mm}] {who}: {message}\n");
            rtbChat.ScrollToCaret();
        }
    }
}
