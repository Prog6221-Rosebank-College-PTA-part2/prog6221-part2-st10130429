# Cybersecurity Awareness Chatbot

## How to Open in Visual Studio Code

1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. Install the C# extension if prompted.
4. Open the terminal in VS Code.
5. Run:

dotnet restore
dotnet run

## Requirements

- .NET 8 SDK installed
- Windows OS

